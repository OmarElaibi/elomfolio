<?php
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="this is Omar Elaibi Portfolio, a young and junior moroccan 
        designer and web developer living in Youssoufia city and trying to make a big carreer. here you can know about him and see a resume of his career.">
    <meta name="keywords" content="omar, elaibi, portfolio, web, design, development, 
        developpeur, developer, designer, youcode, youssoufia, about, à propos">
    <meta name="author" content="Omar Elaibi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Omar Elaibi Portfolio - About</title>
    <link rel="shortcut icon" type="image/png" href="img/favicon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="css/fonts/flaticonfont/flaticon.css">
    <link rel="stylesheet" href="css/style_about.css">
</head>

<body>
    <!-- ABOUT SECTION -->
    <section id="wrapper" class="skewed">
        <div class="layer bottom">
            <div class="content-wrap">
                <img src="./img/aboutme.png" alt="ABOUT ME" id="about_title_normal" class="about_title">
                <img src="img/background-normal.jpg" alt="my pic">
                <a href="https://omarelaibi.github.io/" target="_blank" rel="noopener noreferrer" class="btn btn-lg myresume" id="resume_dev"><?php echo $lang['resume'] ?></a>
                <div class="skills" id="dev_skills">
                    <div>
                        <div id="html"></div>
                        <div>
                            <h4>HTML</h4>
                        </div>
                    </div>
                    <div>
                        <div id="css"></div>
                        <div>
                            <h4>CSS</h4>
                        </div>
                    </div>
                    <div>
                        <div id="js"></div>
                        <div>
                            <h4>JS/JQUERY</h4>
                        </div>
                    </div>
                    <div>
                        <div id="sql"></div>
                        <div>
                            <h4>SQL</h4>
                        </div>
                    </div>
                    <div>
                        <div id="php"></div>
                        <div>
                            <h4>PHP</h4>
                        </div>
                    </div>
                    <div>
                        <div id="bootstrap"></div>
                        <div>
                            <h4>BOOTSTRAP</h4>
                        </div>
                    </div>
                </div>

                <div class="content-body">
                    <h1 id="dev_title"><?php echo $lang['dev_title'] ?></h1><br>
                    <p class="dev_para"><?php echo $lang['dev_para'] ?></p>
                </div>
            </div>
        </div>

        <div class="layer top">
            <div class="content-wrap">
                <img src="./img/aboutme_glitched.png" alt="ABOUT ME" id="about_title_glitch" class="about_title">
                <img src="img/background-glitched.jpg" alt="my pic glitched">
                <a href="https://omarelaibi.github.io/" target="_blank" rel="noopener noreferrer" class="btn btn-lg myresume" id="resume_des"><?php echo $lang['resume'] ?></a>
                <div class="skills" id="des_skills">
                    <div>
                        <div id="photoshop"></div>
                        <div>
                            <h4>PHOTOSHOP</h4>
                        </div>
                    </div>
                    <div>
                        <div id="illustrator"></div>
                        <div>
                            <h4>ILLUSTRATOR</h4>
                        </div>
                    </div>
                    <div>
                        <div id="ae"></div>
                        <div>
                            <h4>AFTER EFFECTS</h4>
                        </div>
                    </div>
                    <div>
                        <div id="creativity"></div>
                        <div>
                            <h4>CREATIVITY</h4>
                        </div>
                    </div>
                    <div>
                        <div id="conception"></div>
                        <div>
                            <h4>CONCEPTION</h4>
                        </div>
                    </div>
                </div>



                <div class="content-body">
                    <h1 id="des_title"><?php echo $lang['des_title'] ?></h1><br>
                    <p class="des_para"><?php echo $lang['des_para'] ?></p>
                </div>
            </div>
        </div>

        <div class="handle"></div>
    </section>
    <!-- END ABOUT SECTION -->

    <!-- LANGUAGES -->
    <div class="languages">
        <img src="./img/en_flag.png" alt="En Lang" id="en_lang">
        <img src="./img/fr_flag.png" alt="Fr Lang" id="fr_lang">
        <form method="get" style="display: none;" id="langForm">
            <input type="hidden" name="lang" id="langValue">
        </form>
    </div>
    <!-- END LANGUAGES -->

    <!-- MENU - BUTTON -->
    <img src="./img/menu_icon.png" alt="menu_icon" id="menu_icon">
    <!-- END MENU - BUTTON -->

    <!-- MUNU -->
    <div class="menu_container">
        <div class="menu_logo">
            <a href="index.php" id="logo_link"><img src="./img/logo.png" alt="logo" id="logo"></a>
        </div>
        <div class="menu_icons">
            <a href="index.php" id="home"><i class="flaticon-home icon"></i></a>
            <a href="about.php" id="about"><i class="flaticon-avatar icon active"></i></a>
            <a href="works.php" id="works">
                <i class="flaticon-briefcase icon"></i>
            </a>
            <a href="contact.php" id="contact"><i class="flaticon-email icon"></i>
            </a>
        </div>
        <div class="social_media">
            <a href="https://github.com/OmarElaibi" target="_blank" rel="noopener noreferrer" id="github" title="github"><i class="flaticon-github social"></i></a>
            <a href="https://ma.linkedin.com/in/omar-elaibi-5526b2173" target="_blank" rel="noopener noreferrer" id="linkedin" title="linkedin"><i class="flaticon-linkedin social"></i></a>
            <a href="https://www.facebook.com/profile.php?id=100010092580990" target="_blank" rel="noopener noreferrer" id="facebook" title="facebook">
                <div class="flaticon-facebook social"></div>
            </a>
        </div>
    </div>
    <!-- END MENU -->
    <!-- MENU MOBILE -->
    <div class="menu_mobile_container">
            <div class="menu_mobile_header">
                <div class="menu_mobile_logo">
                    <a href="index.php" id="logo_mobile_link"><img src="./img/logo.png" alt="logo" id="logo_mobile"></a>
                </div>
                <div class="menu_mobile_icon">
                    <img src="./img/menu_icon.png" alt="menu_icon" id="menu_mobile_icon">      
                </div>
            </div>
            <div class="menu_mobile_icons">
                <a href="index.php" id="home_mobile"><i class="flaticon-home icon"></i></a>
                <a href="about.php" id="about_mobile"><i class="flaticon-avatar icon active"></i></a>
                <a href="works.php" id="works_mobile"><i class="flaticon-briefcase icon"></i></a>
                <a href="contact.php" id="contact_mobile"><i class="flaticon-email icon"></i></a>
            </div>
        </div>
        <!-- END MENU MOBILE -->
</body>
<script src="./js/script_lang.js"></script>
<script src="js/progressbar.min.js"></script>
<script src="js/script_about.js"></script>

</html>