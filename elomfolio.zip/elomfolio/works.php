<?php
include "config.php";
?>
<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8" />
	<meta name="description" content="this is Omar Elaibi Portfolio, a young and junior moroccan 
        designer and web developer living in Youssoufia city and trying to make a big carreer. here you can find a resume of all his works.">
    <meta name="keywords" content="omar, elaibi, portfolio, web, design, development, 
        developpeur, developer, designer, youcode, youssoufia, projets, works">
    <meta name="author" content="Omar Elaibi">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Omar Elaibi Portfolio - My Works</title>
	<link rel="shortcut icon" type="image/png" href="img/favicon.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
	</script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
	</script>
	<link rel="stylesheet" href="css/fonts/flaticonfont/flaticon.css">
	<link rel="stylesheet" type="text/css" href="css/style_works.css" />
	<link rel="stylesheet" type="text/css" href="css/glitch-slideshow.css" />
	<script>
		document.documentElement.className = "js";
		var supportsCssVars = function() {
			var e, t = document.createElement("style");
			return t.innerHTML = "root: { --tmp-var: bold; }", document.head.appendChild(t), e = !!(window.CSS && window
				.CSS.supports && window.CSS.supports("font-weight", "var(--tmp-var)")), t.parentNode.removeChild(t), e
		};
		supportsCssVars() || alert("Please view this demo in a modern browser that supports CSS Variables.");
	</script>
</head>

<body class="demo-2 loading">

	<main>

		<div class="side-content">
			<h1><?php echo $lang['works_title'] ?></h1>
			<p id="para1"><?php echo $lang['works_para1'] ?>
			</p>
			<p id="para2"><?php echo $lang['works_para2'] ?></p>
		</div>

		<div class="content">
			<div class="slides slides--contained effect-2">
				<div class="slide slide--current">
					<div class="slide__img glitch grayscale" style="background-image: url(img/1_1.jpg);"></div>
					<div class="slide__text">
						<h2 class="slide__title"><?php echo $lang['work1_title'] ?></h2>
						<p class="slide__description" style="background: rgba(0,0,0,0.5);"><?php echo $lang['work1_description'] ?></p>
					</div>
				</div>
				<div class="slide">
					<div class="slide__img glitch grayscale" style="background-image: url(img/2_2.jpg);"></div>
					<div class="slide__text">
						<h2 class="slide__title"><?php echo $lang['work2_title'] ?></h2>
						<p class="slide__description" style="background: rgba(0,0,0,0.5);"><?php echo $lang['work2_description'] ?></p>
					</div>
				</div>
				<div class="slide">
					<div class="slide__img glitch grayscale" style="background-image: url(img/3_3.jpg);"></div>
					<div class="slide__text">
						<h2 class="slide__title"><?php echo $lang['work3_title'] ?></h2>
						<p class="slide__description" style="background: rgba(0,0,0,0.5);"><?php echo $lang['work3_description'] ?></p>
					</div>
				</div>
				<div class="slide">
					<div class="slide__img glitch grayscale" style="background-image: url(img/4_4.jpg);"></div>
					<div class="slide__text">
						<h2 class="slide__title"><?php echo $lang['work4_title'] ?></h2>
						<p class="slide__description" style="background: rgba(0,0,0,0.5);"><?php echo $lang['work4_description'] ?></p>
					</div>
				</div>
				<div class="slide">
					<div class="slide__img glitch grayscale" style="background-image: url(img/5_5.jpg);"></div>
					<div class="slide__text">
						<h2 class="slide__title"><?php echo $lang['work5_title'] ?></h2>
						<p class="slide__description" style="background: rgba(0,0,0,0.5);"><?php echo $lang['work5_description'] ?></p>
					</div>
				</div>
			</div>
			<nav class="slide-nav">
				<button class="slide-nav__button"><span><?php echo $lang['previous'] ?></span></button>
				<button class="slide-nav__button"><span><?php echo $lang['next'] ?></span></button>
			</nav>
			<a class="btn btn-warning btn-lg" href="mailto:omar.elaibi@gmail.com" style="z-index:200;" id="mail"><?php echo $lang['check_github'] ?></a>
			<p id="para3"><?php echo $lang['works_para3'] ?></p>
		</div>

		<div class="languages">
		<img src="./img/en_flag.png" alt="En Lang" id="en_lang">
		<img src="./img/fr_flag.png" alt="Fr Lang" id="fr_lang">
		<form method="get" style="display: none;" id="langForm">
			<input type="hidden" name="lang" id="langValue">
		</form>
	</div>
	</main>

	<!-- LANGUAGES -->
	
	<!-- END LANGUAGES -->

	<!-- MENU - BUTTON -->
	<img src="./img/menu_icon.png" alt="menu_icon" id="menu_icon">
	<!-- END MENU - BUTTON -->

	<!-- MUNU -->
	<div class="menu_container">
		<div class="menu_logo">
			<a href="index.php" id="logo_link"><img src="./img/logo.png" alt="logo" id="logo"></a>
		</div>
		<div class="menu_icons">
			<a href="index.php" id="home"><i class="flaticon-home mymenu-icon"></i></a>
			<a href="about.php" id="about"><i class="flaticon-avatar mymenu-icon"></i></a>
			<a href="works.php" id="works">
				<i class="flaticon-briefcase mymenu-icon active"></i>
			</a>
			<a href="contact.php" id="contact"><i class="flaticon-email mymenu-icon "></i>
			</a>
		</div>
		<div class="social_media">
			<a href="https://github.com/OmarElaibi" target="_blank" rel="noopener noreferrer" id="github" title="github"><i class="flaticon-github social"></i></a>
			<a href="https://ma.linkedin.com/in/omar-elaibi-5526b2173" target="_blank" rel="noopener noreferrer" id="linkedin" title="linkedin"><i class="flaticon-linkedin social"></i></a>
			<a href="https://www.facebook.com/profile.php?id=100010092580990" target="_blank" rel="noopener noreferrer" id="facebook" title="facebook">
				<div class="flaticon-facebook social"></div>
			</a>
		</div>
	</div>
	<!-- END MENU -->
	<!-- MENU MOBILE -->
	<div class="menu_mobile_container">
		<div class="menu_mobile_header">
			<div class="menu_mobile_logo">
				<a href="index.php" id="logo_mobile_link"><img src="./img/logo.png" alt="logo" id="logo_mobile"></a>
			</div>
			<div class="menu_mobile_icon">
				<img src="./img/menu_icon.png" alt="menu_icon" id="menu_mobile_icon">
			</div>
		</div>
		<div class="menu_mobile_icons">
			<a href="index.php" id="home_mobile"><i class="flaticon-home icon"></i></a>
			<a href="about.php" id="about_mobile"><i class="flaticon-avatar icon"></i></a>
			<a href="works.php" id="works_mobile"><i class="flaticon-briefcase icon active"></i></a>
			<a href="contact.php" id="contact_mobile"><i class="flaticon-email icon"></i></a>
		</div>
	</div>
	<!-- END MENU MOBILE -->
	<script src="./js/script_lang.js"></script>
	<script src="js/imagesloaded.pkgd.min.js"></script>
	<script src="js/works.js"></script>
	<script src="js/works_2.js"></script>
</body>

</html>