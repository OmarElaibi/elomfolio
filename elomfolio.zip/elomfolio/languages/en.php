<?php
$lang = array(
    "iam" => "Hello World, I am",
    "resume" => "TAKE A LOOK AT MY RESUME",
    "dev_title" => "As Web Developer",
    "dev_para" => "A 24 years old web developer who is passionate about taking web development to another level.<br>
        As a web developer, I passionately work on widening my knowledge in that domain and improve my programming skills whether by creating mock-ups and bringing them to life or by working on several clients' projects.<br> 
        I’m also fully aware it is no easy task to choose such career, for such reason I try to keep myself updated with the up-to-date coding languages, frameworks and technologies, learn 
        several different coding languages and frameworks such as <i style='color: #25F7F4; font-weight: bold'>HTML, CSS, JS, SQL, PHP, JQUERY, BOOTSTRAP and ANGULAR</i>,
         understand today clients’ needs and adapt with them.",
    "des_title" => "As Designer",
    "des_para" => "A young moroccan designer who is driven by his will to learn, discover and develop his skill set in the domain of designing. 
    I've almost always been curious as well as fascinated by web and graphic designs ever since my childhood. 
    Such interest has motivated me to persue my will to be qualified <i style='color: #25F7F4; font-weight: bold'>Web and Graphic Designer</i><br>.
    Fueled by high energy levels and boundless enthousiasm, I try to challenge myself by working on multiple thought-provoking projects in order to develop my abilities and enhance the spirit of discovery and competition.<br>
    Throughout the learning process, I try to add <i style='color: #25F7F4; font-weight: bold'>my own special, creative print</i> so as to add real value to the designs I make.
    ",
    "works_title" => "CHECK MY WORKS",
    "works_para1" => "Many projects were built throughout my career, building them from the sketch and design phase till 
    the production phase with technologies as HTML, CSS, JS, MYSQL, PHP with their frameworks as Bootstrap, Jquery and Angular and designing with Adobe Creative Suite 
    for graphic design.",
    "works_para2" => "In this section you will be able to see a portion of my work with links to their Github repositories.",
    "works_para3" => "Want to see more or just discuss something, click this button to email me :)",
    "check_github" => "EMAIL ME",
    "work1_title" => "STORE <span style='font-size:3rem;'>admin panel</span>",
    "work1_description" => "Check on <a href='#'>github </a>
    this dashboard for a store made as a challenge in only 3 days.",
    "work2_title" => "INSUR'FAQ",
    "work2_description" => "A game made with a team of 50 members
     for insurance agencies and presented to Capgemini. <a href='#'>Check it out.</a>",
    "work3_title" => "Kech <span style='font-size:3rem;'>Marathon Roads</span>",
    "work3_description" => "Mobile app made as my Bachelor's Degree Final Project,
    <a href='#'>check more details on it in this report</a>",
    "work4_title" => "Tower <span style='font-size:3rem;'>of</span> Hanoi",
    "work4_description" => "A web game made with a collegue based on 
    the tower of hanoi famous game. <a href='#'>Check it out.</a>",
    "work5_title" => " Artworks <span style='font-size:3rem;'>Showcase</span>",
    "work5_description" => "A group of some of the artworks I made only
     this year for my school Youcode. <a href='#'>Check them out.</a>",
    "name" => "Name",
    "comments" => "Comments/ Questions",
    "send" => "SEND",
    "previous" => "previous",
    "next" => "next",
    "contact_title" => "LET US GET IN TOUCH",
    "404" => "404_en",
    "home" => "HOME"
);
