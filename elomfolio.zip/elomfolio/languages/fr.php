<?php 
    $lang = array(
        "iam" => "Hello World, Je Suis",
        "resume" => "VOIR MON CV",
        "dev_title" => "En Tant Que Developpeur Web",
        "dev_para" => "Un développeur Web agé de 24 ans qui est passionné par prendre le développement web à un autre niveau. <br>
        Dans toute ma carrière, je travaille passionnément pour élargir ma connaissance dans le domaine et améliorer mes compétences en programmation
        que ça soit par la création des maquettes et leur donner vie ou par travailler sur plusieurs projets des clients. <br>
        J'essaye toujours de rester à jour en ce qui concerne toutes les technologies du web qu'elles soient des langages, bibliothèques ou frameworks
        telles que <i style='color: #25F7F4; font-weight: bold'>HTML, CSS, JS, SQL, PHP, JQUERY, BOOTSTRAP and ANGULAR</i>, ainsi que j'essaye toujours
         de comprendre les besoins des clients d'aujourd'hui.",
        "des_title" => "En Tant Que Designer",
        "des_para" => "Un jeune graphiste marocain qui est emmené par sa volonté d’apprendre, de découvrir et de développer ses compétences dans le domaine du design graphique.
        J'ai toujours été curieux et fasciné par les conceptions Web et graphiques depuis mon enfance.<br>
        Un tel intérêt m'a motivé à poursuivre ma volonté d'être qualifié <i style='color: #25F7F4; font-weight: bold'>un web et graphique designer </i>.
        Alimenté par des niveaux d'énergie élevés et un enthousiasme illimité, j'essaie de me mettre au défi en travaillant sur plusieurs projets stimulants afin de développer mes capacités et de renforcer l'esprit de découverte et de compétition. <br>
        Tout au long de mon processus d’apprentissage, j’essaie toujours d’ajouter <i style='color: #25F7F4; font-weight: bold'>ma propre touche spéciale</i> afin d'ajouter de la valeur réelle aux designs que je fais.
        ",
        "works_title" => "MON PORTFOLIO",
        "works_para1" => "De nombreux projets ont été construits tout au long de ma carrière, de la phase de conception jusqu’à
         la phase de production avec des technologies telles que HTML, CSS, JS, MYSQL, PHP avec leurs frameworks tels que Bootstrap,
          Jquery et Angular et la conception avec Adobe Creative Suite pour le graphisme.",
        "works_para2" => "Dans cette section, vous pourrez voir une partie de mon travail avec des liens vers leurs référentiels Github.",
        "works_para3" => "Vous voulez en voir plus ou simplement discuter de quelque chose, cliquez sur ce bouton pour m'envoyer un email :)",
        "check_github" => "LAISSE MOI UN MAIL",
        "work1_title" => "STORE <span style='font-size:3rem;'>admin panel</span>",
        "work1_description" => "Consulter sur <a href='#'>github </a>
        ce dashboard d'un store qu'on a réalisé dans 3 jours.",
        "work2_title" => "INSUR'FAQ",
        "work2_description" => "Un jeu vidéo réalisé par une équipe de 50 personnes
         pour les assureurs et présenté à Capgemini. <a href='#'>Consulter sur github.</a>",
        "work3_title" => "Kech <span style='font-size:3rem;'>Marathon Roads</span>",
        "work3_description" => "Application mobile réalisé comme PFE de ma 
        licence dans 6 mois. <a href='#'>Consulter plus de détails sur ce rapport.</a>",
        "work4_title" => "Tour <span style='font-size:3rem;'>de</span> Hanoi",
        "work4_description" => "Un jeu web réalisé avec un collègue basé 
        sur le jeu célébre du tour du Hanoi. <a href='#'>Consulter sur github.</a>",
        "work5_title" => "OEUVRES <span style='font-size:4rem;'>d'Art</span>",
        "work5_description" => "une petite collection des oeuvres 
        d'art que j'ai réalisé cette année pour mon école Youcode. <a href='#'>Consulter les.</a>",
        "name" => "Nom",
        "comments" => "Commentaires/ Questions",
        "send" => "ENVOYER",
        "previous" => "précédent",
        "next" => "suivant",
        "contact_title" => "DIS MOI TOUS CE QUE TU VEUX",
        "404" => "404_fr",
        "home" => "ACCEUIL"
    );
