<?php 
    include "config.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="this is Omar Elaibi Portfolio, a young and junior moroccan 
        designer and web developer living in Youssoufia city and trying to make a big carreer.">
    <meta name="keywords" content="omar, elaibi, portfolio, web, design, development, 
        developpeur, developer, designer, youcode, youssoufia">
    <meta name="author" content="Omar Elaibi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Omar Elaibi - Portfolio</title>
    <link rel="shortcut icon" type="image/png" href="img/favicon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="./js/mgGlitch.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/baffle@0.3.6/dist/baffle.min.js"></script> -->
    <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css"> -->
    <link rel="stylesheet" href="css/fonts/flaticonfont/flaticon.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body id="body_container">
    <div class="full-container">
        <!-- DECORATION LINES AND RECTANGLES -->
        <hr id="line_1_d1">
        <hr id="line_1_d2">
        <hr id="line_1">
        <hr id="line_2_d1">
        <hr id="line_2_d2">
        <hr id="line_2">
        <hr id="line_3_d1">
        <hr id="line_3_d2">
        <hr id="line_3">
        <hr id="line_4_d1">
        <hr id="line_4_d2">
        <hr id="line_4">
        <hr id="line_5_d1">
        <hr id="line_5_d2">
        <hr id="line_5">
        <hr id="line_6_d1">
        <hr id="line_6_d2">
        <hr id="line_6">
        <hr id="line_7_d1">
        <hr id="line_7_d2">
        <hr id="line_7">
        <hr id="line_8_d1">
        <hr id="line_8_d2">
        <hr id="line_8">
        <!-- <hr id="line_9">
        <hr id="line_10"> -->
        <!-- END DECORATION -->

        <!-- TEXT -->
        <h5 id="hello_world" class="glitch" data-hello="<?php echo $lang['iam']?>"><?php echo $lang['iam']?></h5>
        <h1 id="full_name" class="glitch">OMAR ELAIBI</h1>
        <h3 id="job" class="glitch"><span id="job_spec" class="glitch"></span></h3>
        <!-- END TEXT -->

        <!-- LOGO -->
        <div class="logo_container">
            <div class="logo_coll">
                <!-- <img src="./img/logo_collection_2.png" alt="Logo" id="logo_coll"> -->
            </div>
        </div>
       
        <!-- END LOGO -->

        <!-- LANGUAGES -->
        <div class="languages">
            <img src="./img/en_flag.png" alt="En Lang" id="en_lang">
            <img src="./img/fr_flag.png" alt="Fr Lang" id="fr_lang">
            <form method="get" style="display: none;" id="langForm">
                <input type="hidden" name="lang" id="langValue">
            </form>
        </div>
        <!-- END LANGUAGES -->

        <!-- MENU - BUTTON -->
        <img src="./img/menu_icon.png" alt="menu_icon" id="menu_icon">
        <!-- END MENU - BUTTON -->

        <!-- MUNU -->
        <div class="menu_container">
            <div class="menu_logo">
                <a href="index.php" id="logo_link"><img src="./img/logo.png" alt="logo" id="logo"></a>
            </div>
            <div class="menu_icons">
                <a href="index.php" id="home"><i class="flaticon-home icon active"></i></a>
                <a href="about.php" id="about"><i class="flaticon-avatar icon"></i></a>
                <a href="works.php" id="works"><i class="flaticon-briefcase icon"></i></a>
                <a href="contact.php" id="contact"><i class="flaticon-email icon"></i>
                </a>
            </div>
            <div class="social_media">
                <a href="https://github.com/OmarElaibi" target="_blank" rel="noopener noreferrer" id="github" title="github"><i class="flaticon-github social"></i></a>
                <a href="https://ma.linkedin.com/in/omar-elaibi-5526b2173" target="_blank" rel="noopener noreferrer" id="linkedin" title="linkedin"><i class="flaticon-linkedin social"></i></a>
                <a href="https://www.facebook.com/profile.php?id=100010092580990" target="_blank" rel="noopener noreferrer" id="facebook" title="facebook"><div class="flaticon-facebook social"></div></a>
            </div>
        </div>
        <!-- END MENU -->

        <!-- MENU MOBILE -->
        <div class="menu_mobile_container">
            <div class="menu_mobile_header">
                <div class="menu_mobile_logo">
                    <a href="index.php" id="logo_mobile_link"><img src="./img/logo.png" alt="logo" id="logo_mobile"></a>
                </div>
                <div class="menu_mobile_icon">
                    <img src="./img/menu_icon.png" alt="menu_icon" id="menu_mobile_icon">      
                </div>
            </div>
            <div class="menu_mobile_icons">
                <a href="index.php" id="home_mobile"><i class="flaticon-home icon active"></i></a>
                <a href="about.php" id="about_mobile"><i class="flaticon-avatar icon"></i></a>
                <a href="works.php" id="works_mobile"><i class="flaticon-briefcase icon"></i></a>
                <a href="contact.php" id="contact_mobile"><i class="flaticon-email icon"></i></a>
            </div>
        </div>
        <!-- END MENU MOBILE -->
    </div>
</body>
<script src="./js/script_lang.js"></script>
<script src="./js/script.js"></script>
</html>