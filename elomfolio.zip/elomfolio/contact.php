<?php
    include "config.php";
    
    $headers = "From: omar.elaibi@gmail.com" . "\r\n" .
    "MIME-Version: 1.0" . "\r\n" . 
    "Content-Type: text/html; charset=utf-8";

    if(isset($_POST['send'])) {
        $name = $_POST['name'];
        $mail = $_POST['mail'];
        $message = $_POST['message'];
        mail("omar.elaibi@gmail.com", "From: $mail", "$name said: $message", $headers);
        if($_SESSION['lang'] == 'fr') {
            echo "<script> alert('message envoyé avec succès!!! je te répondrai le plutot possible $name'); </script>";
        } else if($_SESSION['lang'] == 'en') {
            echo "<script> alert('message sent successfully!!! I'll reply as soon as possible $name'); </script>";
        }
        // header("location: contact.php");
    }
    // var_dump($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="this is Omar Elaibi Portfolio, a young and junior moroccan 
        designer and web developer living in Youssoufia city and trying to make a big carreer. here you can contact him for any thing you want">
    <meta name="keywords" content="omar, elaibi, portfolio, web, design, development, 
        developpeur, developer, designer, youcode, youssoufia">
    <meta name="author" content="Omar Elaibi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Omar Elaibi Portfolio - Contact</title>
    <link rel="shortcut icon" type="image/png" href="img/favicon.png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="./js/mgGlitch.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
    </script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/baffle@0.3.6/dist/baffle.min.js"></script> -->
    <!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css"> -->
    <link rel="stylesheet" href="css/fonts/flaticonfont/flaticon.css">
    <link rel="stylesheet" href="css/style_contact.css">
</head>

<body>
    <div class="full-container">
        <!-- DECORATION LINES -->
        <hr id="line_1_d1">
        <hr id="line_1_d2">
        <hr id="line_1">
        <hr id="line_2_d1">
        <hr id="line_2_d2">
        <hr id="line_2">
        <hr id="line_3_d1">
        <hr id="line_3_d2">
        <hr id="line_3">
        <hr id="line_6_d1">
        <hr id="line_6_d2">
        <hr id="line_6">
        <hr id="line_7_d1">
        <hr id="line_7_d2">
        <hr id="line_7">
        <hr id="line_8_d1">
        <hr id="line_8_d2">
        <hr id="line_8">
        <!-- END DECORATION -->

        <!-- TITLE -->

        <h1 id="contact_title"><?php echo $lang['contact_title']?></h1>

        <!-- END TITLE -->

        <div class="form_bg_container">
            <div class="form_bg">
                <!-- <img src="./img/discussion_glitched.png" id="form_bg"> -->
            </div>
        </div>

        <!-- FORM -->

        <div class="form_container">
            <form action="" method="post">
                <div class="inputBox">
                    <img src="./img/user.png" alt="">
                    <input name="name" type="text" required>
                    <label><?php echo $lang['name']?></label>
                </div>
                <div class="inputBox">
                    <img src="./img/arobasc.png" alt="">
                    <input type="email" id="email" name="mail" required>
                    <label>Email</label>
                </div>
                <div class="inputBox">
                    <img src="./img/mail.png" alt="">
                    <input type="text" name="message" required>
                    <label><?php echo $lang['comments']?></label>
                </div>
                <button type="submit" class="btn btn-lg submit-btn" name="send"><span id="send"><?php echo $lang['send']?></span></button>
            </form>
        </div>

        <!-- END FROM -->

        <!-- LANGUAGES -->
        <div class="languages">
            <img src="./img/en_flag.png" alt="En Lang" id="en_lang">
            <img src="./img/fr_flag.png" alt="Fr Lang" id="fr_lang">
            <form method="get" style="display: none;" id="langForm">
                <input type="hidden" name="lang" id="langValue">
            </form>
        </div>
        <!-- END LANGUAGES -->

        <!-- MENU - BUTTON -->
        <img src="./img/menu_icon.png" alt="menu_icon" id="menu_icon">
        <!-- END MENU - BUTTON -->

        <!-- MUNU -->
        <div class="menu_container">
            <div class="menu_logo">
                <a href="index.php" id="logo_link"><img src="./img/logo.png" alt="logo" id="logo"></a>
            </div>
            <div class="menu_icons">
                <a href="index.php" id="home"><i class="flaticon-home icon active"></i></a>
                <a href="about.php" id="about"><i class="flaticon-avatar icon"></i></a>
                <a href="works.php" id="works"><i class="flaticon-briefcase icon"></i></a>
                <a href="contact.php" id="contact"><i class="flaticon-email icon"></i>
                </a>
            </div>
            <div class="social_media">
                <a href="https://github.com/OmarElaibi" target="_blank" rel="noopener noreferrer" title="github"><i class="flaticon-github social"></i></a>
                <a href="https://ma.linkedin.com/in/omar-elaibi-5526b2173" target="_blank" rel="noopener noreferrer" id="linkedin" title="linkedin"><i class="flaticon-linkedin social"></i></a>
                <a href="https://www.facebook.com/profile.php?id=100010092580990" target="_blank" rel="noopener noreferrer" id="facebook" title="facebook">
                    <div class="flaticon-facebook social"></div>
                </a>
            </div>
        </div>
        <!-- END MENU -->
        <!-- MENU MOBILE -->
        <div class="menu_mobile_container">
            <div class="menu_mobile_header">
                <div class="menu_mobile_logo">
                    <a href="index.php" id="logo_mobile_link"><img src="./img/logo.png" alt="logo" id="logo_mobile"></a>
                </div>
                <div class="menu_mobile_icon">
                    <img src="./img/menu_icon.png" alt="menu_icon" id="menu_mobile_icon">      
                </div>
            </div>
            <div class="menu_mobile_icons">
                <a href="index.php" id="home_mobile"><i class="flaticon-home icon"></i></a>
                <a href="about.php" id="about_mobile"><i class="flaticon-avatar icon"></i></a>
                <a href="works.php" id="works_mobile"><i class="flaticon-briefcase icon"></i></a>
                <a href="contact.php" id="contact_mobile"><i class="flaticon-email icon active"></i></a>
            </div>
        </div>
        <!-- END MENU MOBILE -->
    </div>
</body>
<script src="./js/script_lang.js"></script>
<script src="./js/script_contact.js"></script>

</html>