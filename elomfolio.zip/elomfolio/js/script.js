$(function () {
  $('#full_name').hover(function () {
    $('#line_9').css('opacity', '0.5');
  }, function () {
    // on mouseout, reset the background colour
    $('#line_9').css('opacity', '');
  });
});

$(function () {
  $('#job').hover(function () {
    $('#line_10').css('opacity', '0.5');
  }, function () {
    // on mouseout, reset the background colour
    $('#line_10').css('opacity', '');
  });
});


var currentImage = 0;
var lis = ["./img/menu_icon.png", "./img/menu_icon3.png", "./img/menu_icon2.png"];

function getNextImg() {
  var url = lis[currentImage];

  if (lis[currentImage]) {
    currentImage++;
  } else {
    currentImage = 0;
  }

  return url;
}

var delay;

$(function () {
  $('#menu_icon').hover(function () {
    delay = setInterval(function () {
      $('#menu_icon').attr("src", getNextImg());
    }, 100);
  }, function () {
    // on mouseout, reset the background colour
    clearInterval(delay);
    $(this).attr("src", "./img/menu_icon.png");
  });
});

$(function () {
  $('.logo_coll').mgGlitch({
    destroy: false,
    glitch: true,
    scale: false,
    blend: false,
    blendModeType: 'hue',
    glitch1TimeMin: 200,
    glitch1TimeMax: 400,
    glitch2TimeMin: 10,
    glitch2TimeMax: 100
  });
});

// $(function () {
//   var jobs = ["Web Developer", "Designer"];
//   var i = 0;
//   setInterval(function(){
//     $('#job_spec').html(jobs[i]);
//     $('#job').attr('data-job', 'I am a ' + jobs[i]);
//     i++;
//     if(i==2) {
//       i=0;
//     }
//   }, 3000);
  
// });




setTimeout(
  function () {
    $('#logo_coll').css('transform', 'scale(1,1)');
    $('#logo_coll').css('opacity', '1');
  }, 5301);

$(document).ready(function () {
  setTimeout(
    function () {
      $('#logo_coll').css({
        scale: '1'
      }, 1500);
    }, 3800);
});


$(document).ready(function () {
  var boxWidth = "5vw";
  $("#menu_icon").click(function () {
    $("#menu_icon").animate({
      opacity: 0
    });
    $(".menu_container").animate({
      width: boxWidth
    });
  });
  $(".menu_container").mouseleave(function () {
    $(".menu_container").delay(1000).animate({
      width: 0
    });
    $("#menu_icon").delay(1200).animate({
      opacity: 1
    });
  });

  $(".menu_container").hover(
    function(e){
      $(".menu_container").stop(true).animate({
        width: boxWidth
      });
    },
    function(e){
      $(".menu_container").animate({
        width: 0
      });
        
    }
);
});

// $(function () {
//   $('#logo_coll').hover(function () {
//     $('#logo_coll').effect( "shake" );
//   }, function () {
//     // on mouseout, reset the background colour
//     $('#logo_coll').effect('');
//   });
// });


// const name = baffle("#full_name");
// name.set({
//   characters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
//   speed: 100
// });
// name.start();
// name.reveal(3000, 950);

// const job = baffle("#job");
// job.set({
//   characters: "AaBbCcDd",
//   speed: 100
// });
// job.start();
// job.reveal(3000, 1950);


// ***********************************************************

// ——————————————————————————————————————————————————
// TextScramble
// ——————————————————————————————————————————————————

class TextScramble {
  constructor(el) {
    this.el = el;
    this.chars = '!<>-_\\/[]{}—=+*^?#________';
    this.update = this.update.bind(this);
  }
  setText(newText) {
    const oldText = this.el.innerText;
    const length = Math.max(oldText.length, newText.length);
    const promise = new Promise(resolve => this.resolve = resolve);
    this.queue = [];
    for (let i = 0; i < length; i++) {
      const from = oldText[i] || '';
      const to = newText[i] || '';
      const start = Math.floor(Math.random() * 40);
      const end = start + Math.floor(Math.random() * 40);
      this.queue.push({ from, to, start, end });
    }
    cancelAnimationFrame(this.frameRequest);
    this.frame = 0;
    this.update();
    return promise;
  }
  update() {
    let output = '';
    let complete = 0;
    for (let i = 0, n = this.queue.length; i < n; i++) {
      let { from, to, start, end, char } = this.queue[i];
      if (this.frame >= end) {
        complete++;
        output += to;
      } else if (this.frame >= start) {
        if (!char || Math.random() < 0.28) {
          char = this.randomChar();
          this.queue[i].char = char;
        }
        output += `<span class="dud">${char}</span>`;
      } else {
        output += from;
      }
    }
    this.el.innerHTML = output;
    if (complete === this.queue.length) {
      this.resolve();
    } else {
      this.frameRequest = requestAnimationFrame(this.update);
      this.frame++;
    }
  }
  randomChar() {
    return this.chars[Math.floor(Math.random() * this.chars.length)];
  }}


// ——————————————————————————————————————————————————
// Example
// ——————————————————————————————————————————————————

const phrases = [
'A Web Developer',
'A Web Designer'];


const el = document.querySelector('#job_spec');
const fx = new TextScramble(el);

let counter = 0;
const next = () => {
  $('#job').attr('data-job','');
  fx.setText(phrases[counter]).then(() => {
    $('#job').attr('data-job', $('#job_spec').html());
    console.log($('#job_spec').html());
    setTimeout(next, 3000);
  });
  counter = (counter + 1) % phrases.length;
};

setTimeout(next, 2800);



// NAVIGATION

$(document).keydown(function(e){
  if (e.which == 39) { 
      window.location.href = "about.php";
  }
});

// END NAVIGATION

$('.menu_mobile_icons').hide();


$('#menu_mobile_icon').click(function(){
   $('.menu_mobile_icons').toggle();
});

$(document).mouseup(function(e){
  var icons = $('.menu_mobile_icons');
  if(!icons.is(e.target) && icons.has(e.target).length === 0 && !$('#menu_mobile_icon').is(e.target)) {
    $('.menu_mobile_icons').hide();
  }
});

