$(document).ready(function(){
  if(window.innerHeight > window.innerWidth){
    alert("Please use Landscape for better view!");
}
});

document.addEventListener('DOMContentLoaded', function () {
    let wrapper = document.getElementById('wrapper');
    let topLayer = wrapper.querySelector('.top');
    let handle = wrapper.querySelector('.handle');
    let skew = 0;
    let delta = 0;

    if (wrapper.className.indexOf('skewed') != -1) {
        skew = 1000;
    }

    wrapper.addEventListener('mousemove', function (e) {
        delta = (e.clientX - window.innerWidth / 2) * 0.5;

        handle.style.left = e.clientX + delta + 'px';

        topLayer.style.width = e.clientX + skew + delta + 'px';
    });

    wrapper.addEventListener('touchmove', function (e) {
      delta = (e.touches[0].clientX - window.innerWidth / 2) * 0.5;

      handle.style.left = e.touches[0].clientX + delta + 'px';

      topLayer.style.width = e.touches[0].clientX + skew + delta + 'px';
  });
});


// **************  MENU  ***************

var currentImage = 0;
var lis = ["./img/menu_icon.png", "./img/menu_icon3.png", "./img/menu_icon2.png"];

function getNextImg() {
    var url = lis[currentImage];

    if (lis[currentImage]) {
        currentImage++;
    } else {
        currentImage = 0;
    }

    return url;
}

var delay;

$(function () {
    $('#menu_icon').hover(function () {
        delay = setInterval(function () {
            $('#menu_icon').attr("src", getNextImg());
        }, 100);
    }, function () {
        // on mouseout, reset the background colour
        clearInterval(delay);
        $(this).attr("src", "./img/menu_icon.png");
    });
});

$(document).ready(function () {
    var boxWidth = "5vw";
    $("#menu_icon").click(function () {
        $("#menu_icon").animate({
            opacity: 0
        });
        $(".menu_container").animate({
            marginLeft: '0vw',
            width: boxWidth
        });
    });
    $(".menu_container").mouseleave(function () {
        $(".menu_container").delay(1000).animate({
            marginLeft: '-5vw',
            width: 0
        });
        $("#menu_icon").delay(1200).animate({
            opacity: 1
        });
    });

    $(".menu_container").hover(
        function (e) {
            $(".menu_container").stop(true).animate({
                marginLeft: '0vw',
                width: boxWidth
            });
        },
        function (e) {
            $(".menu_container").animate({
                marginLeft: '-5vw',
                width: 0
            });

        }
    );
});

// **************  END MENU  ***************

// ************** SKILLS BARS ***************

  var htmlBar = new ProgressBar.Circle('#html', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  htmlBar.animate(0.85);  // Number from 0.0 to 1.0

  var cssBar = new ProgressBar.Circle('#css', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  cssBar.animate(0.85);  // Number from 0.0 to 1.0

  var jsBar = new ProgressBar.Circle('#js', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  jsBar.animate(0.75);  // Number from 0.0 to 1.0

  var sqlBar = new ProgressBar.Circle('#sql', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  sqlBar.animate(0.55);  // Number from 0.0 to 1.0

  var phpBar = new ProgressBar.Circle('#php', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  phpBar.animate(0.65);  // Number from 0.0 to 1.0

  var bootstrapBar = new ProgressBar.Circle('#bootstrap', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  bootstrapBar.animate(0.65);  // Number from 0.0 to 1.0

  var psBar = new ProgressBar.Circle('#photoshop', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  psBar.animate(0.75);  // Number from 0.0 to 1.0

  var aiBar = new ProgressBar.Circle('#illustrator', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  aiBar.animate(0.8);  // Number from 0.0 to 1.0

  var aeBar = new ProgressBar.Circle('#ae', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  aeBar.animate(0.5);  // Number from 0.0 to 1.0

  var creativityBar = new ProgressBar.Circle('#creativity', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  creativityBar.animate(0.9);  // Number from 0.0 to 1.0

  var conceptionBar = new ProgressBar.Circle('#conception', {
    color: '#FF0031',
    trailColor: '#FF0031',
    trailWidth: 1,
    duration: 1000,
    easing: 'bounce',
    strokeWidth: 10,
    from: {color: '#FF0031', a:0},
    to: {color: '#25F7F4', a:1},
    // Set default step function for all animate calls
    step: function(state, circle) {
      circle.path.setAttribute('stroke', state.color);
    }
  });
  
  conceptionBar.animate(0.75);  // Number from 0.0 to 1.0

  $('#html').mouseenter(function() {
      console.log('hovered');
      htmlBar.animate(0, function(){
        htmlBar.animate(0.85);
      });
  });

  $('#css').mouseenter(function() {
    cssBar.animate(0, function(){
        cssBar.animate(0.85); 
    });  
});

$('#js').mouseenter(function() {
    jsBar.animate(0, function(){
        jsBar.animate(0.75);
    });
});

$('#sql').mouseenter(function() {
    sqlBar.animate(0, function(){
        sqlBar.animate(0.55);
    });
});

$('#php').mouseenter(function() {
    phpBar.animate(0, function(){
        phpBar.animate(0.65);
    });
});

$('#bootstrap').mouseenter(function() {
    bootstrapBar.animate(0, function(){
        bootstrapBar.animate(0.65);
    });
});

$('#photoshop').mouseenter(function() {
    psBar.animate(0, function(){
        psBar.animate(0.75);
    });
});

$('#illustrator').mouseenter(function() {
    aiBar.animate(0, function(){
        aiBar.animate(0.8);
    });
});

$('#ae').mouseenter(function() {
    aeBar.animate(0, function(){
        aeBar.animate(0.5);
    });
});

$('#creativity').mouseenter(function() {
    creativityBar.animate(0, function(){
        creativityBar.animate(0.9);
    });
});

$('#conception').mouseenter(function() {
    conceptionBar.animate(0, function(){
        conceptionBar.animate(0.75);
    });
});

// ******************************************

// ***************** RESUME ******************

$('#resume_des').mouseenter(function(){
    $('#resume_des').addClass("des_hover");
    $('#resume_dev').addClass("dev_hover");
});

$('#resume_des').mouseleave(function(){
    $('#resume_des').removeClass("des_hover");
    $('#resume_dev').removeClass("dev_hover");
});

$('#resume_dev').mouseenter(function(){
    $('#resume_des').addClass("des_hover");
    $('#resume_dev').addClass("dev_hover");
});

$('#resume_dev').mouseleave(function(){
    $('#resume_des').removeClass("des_hover");
    $('#resume_dev').removeClass("dev_hover");
});

// *******************************************

$(document).keydown(function(e){
	if (e.which == 37) { 
    window.location.href = "index.php";
    console.log("37");
	} else if (e.which == 39) { 
		window.location.href = "works.php";
	}
  });

  $('.menu_mobile_icons').hide();


$('#menu_mobile_icon').click(function(){
   $('.menu_mobile_icons').toggle();
});

$(document).mouseup(function(e){
  var icons = $('.menu_mobile_icons');
  if(!icons.is(e.target) && icons.has(e.target).length === 0 && !$('#menu_mobile_icon').is(e.target)) {
    $('.menu_mobile_icons').hide();
  }
});