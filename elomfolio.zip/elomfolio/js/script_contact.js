$('#email').focusout(function () {
    var VAL = $(this).val();

    var email = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,})+$/;
    var anytxt = /^([a-zA-Z0-9_\.\-\+])+$/;

    if (!email.test(VAL)) {
        if (anytxt.test(VAL)) {
            var txt = $('#email').val() + "@gmail.com";
            $('#email').val(txt);
        } else if ($('#email').val() == "") {
            $('#email').val("");
        } else {
            $('#email').val("youremail@server.com");
        }
        console.log($('#email').val());
    } else console.log($('#email').val());
});

// *************** GLITCH BACKGROUND *************** //

$(function () {
    $('.form_bg').mgGlitch({
        destroy: false,
        glitch: true,
        scale: false,
        blend: false,
        blendModeType: 'hue',
        glitch1TimeMin: 200,
        glitch1TimeMax: 400,
        glitch2TimeMin: 10,
        glitch2TimeMax: 100
    });
});

// *********** END GLITCH BACKGROUND ************** //

// *************** MENU ICON CHANGE *************** //

var currentImage = 0;
var lis = ["./img/menu_icon.png", "./img/menu_icon3.png", "./img/menu_icon2.png"];

function getNextImg() {
    var url = lis[currentImage];

    if (lis[currentImage]) {
        currentImage++;
    } else {
        currentImage = 0;
    }

    return url;
}

var delay;

$(function () {
    $('#menu_icon').hover(function () {
        delay = setInterval(function () {
            $('#menu_icon').attr("src", getNextImg());
        }, 100);
    }, function () {
        // on mouseout, reset the background colour
        clearInterval(delay);
        $(this).attr("src", "./img/menu_icon.png");
    });
});

// *************** END MENU ICON CHANGE *************** //

// *************** MENU SLIDE IN *************** //

$(document).ready(function () {
    var boxWidth = "5vw";
    $("#menu_icon").click(function () {
      $("#menu_icon").animate({
        opacity: 0
      });
      $(".menu_container").animate({
        width: boxWidth
      });
    });
    $(".menu_container").mouseleave(function () {
      $(".menu_container").delay(1000).animate({
        width: 0
      });
      $("#menu_icon").delay(1200).animate({
        opacity: 1
      });
    });
  
    $(".menu_container").hover(
      function(e){
        $(".menu_container").stop(true).animate({
          width: boxWidth
        });
      },
      function(e){
        $(".menu_container").animate({
          width: 0
        });
          
      }
  );
  });

  // *************** END MENU SLIDE IN *************** //

  $(document).keydown(function(e){
    if (e.which == 37) { 
        window.location.href = "works.php";
        console.log("37");
    }
  });

  $('.menu_mobile_icons').hide();


$('#menu_mobile_icon').click(function(){
   $('.menu_mobile_icons').toggle();
});

$(document).mouseup(function(e){
  var icons = $('.menu_mobile_icons');
  if(!icons.is(e.target) && icons.has(e.target).length === 0 && !$('#menu_mobile_icon').is(e.target)) {
    $('.menu_mobile_icons').hide();
  }
});
