$('#en_lang').click();

$('#en_lang').click(function(){
    $('#langValue').val('en');
    $('#langForm').submit();
});

$('#fr_lang').click(function(){
    $('#langValue').val('fr');
    $('#langForm').submit();
});