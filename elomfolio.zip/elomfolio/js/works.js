/**
 * demo.js
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2017, Codrops
 * http://www.codrops.com
 */
{
	setTimeout(() => document.body.classList.add('render'), 60);
	const navdemos = Array.from(document.querySelectorAll('nav.demos > .demo'));
	const total = navdemos.length;
	const current = navdemos.findIndex(el => el.classList.contains('demo--current'));
	const navigate = (linkEl) => {
		document.body.classList.remove('render');
		document.body.addEventListener('transitionend', () => window.location = linkEl.href);
	};
	navdemos.forEach(link => link.addEventListener('click', (ev) => {
		ev.preventDefault();
		navigate(ev.target);
	}));
	// document.addEventListener('keydown', (ev) => {
	// 	const keyCode = ev.keyCode || ev.which;
	// 	let linkEl;
	// 	if ( keyCode === 37 ) {
	// 		linkEl = current > 0 ? navdemos[current-1] : navdemos[total-1];
	// 	}
	// 	else if ( keyCode === 39 ) {
	// 		linkEl = current < total-1 ? navdemos[current+1] : navdemos[0];
	// 	}
	// 	else {
	// 		return false;
	// 	}
	// 	navigate(linkEl);
	// });
}

$(document).ready(function () {
	$(".slide__img").mouseover(function () {
		$(".grayscale").removeClass("grayscale").fadeTo(400, 1);
	});
	$(".slide__img").mouseout(function () {
		$(".slide__img").addClass("grayscale").fadeTo(400, 1);
	});
});

$(window).resize(function () {
	if(window.innerHeight > window.innerWidth) {
		$(".grayscale").removeClass("grayscale").fadeTo(400, 1);
	} else {
		$(".slide__img").addClass("grayscale").fadeTo(400, 1);
	}
});

$(document).ready(function () {
	if(window.innerHeight > window.innerWidth) {
		$(".grayscale").removeClass("grayscale").fadeTo(400, 1);
	} else {
		$(".slide__img").addClass("grayscale").fadeTo(400, 1);
	}
});

$(document).keydown(function(e){
	if (e.which == 37) { 
		window.location.href = "about.php";
		console.log("37");
	} else if (e.which == 39) { 
		window.location.href = "contact.php";
	}
  });

  $('.menu_mobile_icons').hide();


$('#menu_mobile_icon').click(function(){
   $('.menu_mobile_icons').toggle();
});

$(document).mouseup(function(e){
	var icons = $('.menu_mobile_icons');
	if(!icons.is(e.target) && icons.has(e.target).length === 0 && !$('#menu_mobile_icon').is(e.target)) {
	  $('.menu_mobile_icons').hide();
	}
  });
