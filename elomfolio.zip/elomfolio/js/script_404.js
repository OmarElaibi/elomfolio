$(function () {
    $('.background_container').mgGlitch({
        destroy: false,
        glitch: true,
        scale: false,
        blend: false,
        blendModeType: 'hue',
        glitch1TimeMin: 200,
        glitch1TimeMax: 400,
        glitch2TimeMin: 10,
        glitch2TimeMax: 100
    });
});